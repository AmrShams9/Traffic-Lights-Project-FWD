#include "Application/App.h"

int main(void){
	appInit();
	while (1) {
		appStart();
	}
}