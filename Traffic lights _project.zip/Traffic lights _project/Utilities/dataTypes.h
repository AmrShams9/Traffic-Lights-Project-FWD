#ifndef DATATYPES_H_
#define DATATYPES_H_

typedef unsigned char uint8_t;


#endif /* DATATYPES_H_ */